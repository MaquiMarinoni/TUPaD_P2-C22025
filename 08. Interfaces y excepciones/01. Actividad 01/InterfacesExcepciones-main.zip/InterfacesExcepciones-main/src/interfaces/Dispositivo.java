package interfaces;

public class Dispositivo {

    public void encender() {
        System.out.print("Encendiendo...");
    }
}
