package interfaces;

public class Ave {

    public void ponerHuevos() {
        System.out.println("Poniendo huevos...");
    }
}
