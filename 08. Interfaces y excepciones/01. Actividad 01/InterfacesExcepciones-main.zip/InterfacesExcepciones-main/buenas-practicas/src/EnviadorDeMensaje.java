

public interface EnviadorDeMensaje {

    public abstract void enviarMensaje(String mensaje);
}

