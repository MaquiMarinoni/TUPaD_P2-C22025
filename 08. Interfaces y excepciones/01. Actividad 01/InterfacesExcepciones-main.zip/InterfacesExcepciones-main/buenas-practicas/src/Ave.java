
public class Ave {
    public void volar(){
        System.out.println("Estoy volando");
    }
}