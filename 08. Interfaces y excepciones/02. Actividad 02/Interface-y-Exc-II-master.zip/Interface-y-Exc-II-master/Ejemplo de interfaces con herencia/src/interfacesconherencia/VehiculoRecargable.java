package interfacesconherencia;

public interface VehiculoRecargable extends Recargable, Vehiculo {

}
