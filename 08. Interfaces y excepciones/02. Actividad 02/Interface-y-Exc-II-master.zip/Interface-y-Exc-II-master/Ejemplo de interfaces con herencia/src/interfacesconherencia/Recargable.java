package interfacesconherencia;

public interface Recargable {

    public abstract void recargar();
}
