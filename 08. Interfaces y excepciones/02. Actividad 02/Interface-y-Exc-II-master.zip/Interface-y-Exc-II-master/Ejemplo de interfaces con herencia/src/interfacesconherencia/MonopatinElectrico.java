package interfacesconherencia;

public class MonopatinElectrico implements VehiculoRecargable {

    @Override
    public void recargar() {

    }

    @Override
    public void acelerar() {

    }

}
