package interfacesconherencia;

public interface Vehiculo {

    public abstract void acelerar();
}
