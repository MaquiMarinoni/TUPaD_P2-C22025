
package ejercicio_V;

public interface Aprobable {
    public abstract boolean aprobo();
}
