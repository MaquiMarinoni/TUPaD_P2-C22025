
package ejercicio_V;


public enum NivelSatisfaccion {
    INSUFICIENTE, SUFICIENTE, EXCELENTE;
}
