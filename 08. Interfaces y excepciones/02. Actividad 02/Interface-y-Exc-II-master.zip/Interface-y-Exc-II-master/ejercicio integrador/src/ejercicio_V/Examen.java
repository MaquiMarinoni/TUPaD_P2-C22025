
package ejercicio_V;

public abstract class Examen implements Aprobable {
    private String fecha;

    public Examen(String fecha) {
        this.fecha = fecha;
    }
    
}
