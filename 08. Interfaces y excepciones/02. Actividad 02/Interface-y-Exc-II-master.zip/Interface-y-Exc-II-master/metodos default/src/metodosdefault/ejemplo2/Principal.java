package metodosdefault.ejemplo2;

public class Principal {

    public static void main(String[] args) {
        Persona p = new Persona();
        p.realizarTarea();
    }

}
