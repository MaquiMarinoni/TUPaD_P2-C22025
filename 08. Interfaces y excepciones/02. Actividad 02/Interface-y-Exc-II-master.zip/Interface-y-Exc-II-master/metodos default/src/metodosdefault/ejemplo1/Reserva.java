package metodosdefault.ejemplo1;

public class Reserva implements Identificable {

}
