package metodosdefault.ejemplo1;

public class Automovil implements Identificable {

}
