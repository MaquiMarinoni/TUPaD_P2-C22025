
package com.mycompany.comparable;

/**
 *
 * @author Usuario
 */
public enum EstadoCivil {
    
    CASADO, SOLTERO, DIVORCIADO, VIUDO;
}
