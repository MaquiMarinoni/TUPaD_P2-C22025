
package ContadorFor;


public class ContadorFor {

    public static void main(String[] args) {
        System.out.println("FOR: Mostrar los primeros 10 números");
        for (int i = 1; i <= 10; i++) {
        System.out.println("Número: " + i);
        }
    }
    
}
