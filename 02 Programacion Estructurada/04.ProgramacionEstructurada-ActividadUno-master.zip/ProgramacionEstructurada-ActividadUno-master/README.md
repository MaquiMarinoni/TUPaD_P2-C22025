# 🧮 Proyecto Java – Operadores y Condicionales

Este proyecto tiene como objetivo demostrar el uso práctico de **operadores relacionales**, **comparaciones de cadenas con `equals`**, y la aplicación de **condicional múltiple con `switch`** para implementar una calculadora básica en Java.  

---

## 📚 Tabla de Contenidos

- [Introducción](#💡-introducción)  
- [Objetivos](#🎯-objetivos)  
- [Conceptos Implementados](#⚙️-conceptos-implementados)  
  - [Operadores Relacionales](#🔹-operadores-relacionales)  
  - [Uso de `equals`](#🔹-uso-de-equals)  
  - [Condicional múltiple con switch](#🔹-condicional-múltiple-con-switch-calculadora)  
- [Ejemplo de uso](#🖥️-ejemplo-de-uso)  
- [Conclusión y aprendizaje](#✅-conclusión-y-aprendizaje)  

---

## 💡 Introducción

En programación estructurada, es esencial comprender cómo comparar valores y tomar decisiones en base a condiciones. Este proyecto refuerza esos conceptos fundamentales en Java a través de ejemplos prácticos:  

- Comparaciones con operadores relacionales.  
- Comparación correcta de cadenas con `equals`.  
- Implementación de una calculadora con condicional múltiple (`switch`).  

---

## 🎯 Objetivos

- Comprender y aplicar operadores relacionales.  
- Diferenciar entre `==` y `equals` en Java.  
- Usar estructuras de control condicional (`switch`) para resolver problemas prácticos.  
- Fortalecer la lógica de programación básica.  

---

## ⚙️ Conceptos Implementados

### 🔹 Operadores Relacionales

Ejemplo de salida en consola:  
```java
System.out.println("4 < 5:  " + (4 < 5));
System.out.println("5 <= 5: " + (5 <= 5));
System.out.println("4 > 5:  " + (4 > 5));
System.out.println("5 >= 5: " + (5 >= 5));
System.out.println("4 == 5: " + (4 == 5));
System.out.println("4 != 5: " + (4 != 5));
```

👉 Se muestran los resultados de distintas comparaciones lógicas.  

---

### 🔹 Uso de `equals`

```java
String cadena1 = "Hola";
String cadena2 = "Hola";
String cadena3 = new String("Hola");

System.out.println("cadena1 == cadena2: " + (cadena1 == cadena2));
System.out.println("cadena1 == cadena3: " + (cadena1 == cadena3));
System.out.println("cadena1.equals(cadena3): " + cadena1.equals(cadena3));
```

👉 Se demuestra la diferencia entre usar `==` (compara referencias) y `equals` (compara contenido).  

---

### 🔹 Condicional múltiple con `switch` (Calculadora)

```java
Scanner sc = new Scanner(System.in);

System.out.print("Ingrese primer número: ");
int num1 = sc.nextInt();
System.out.print("Ingrese segundo número: ");
int num2 = sc.nextInt();

System.out.println("Seleccione operación: 1=Suma, 2=Resta, 3=Multiplicación, 4=División");
int opcion = sc.nextInt();

switch (opcion) {
    case 1 -> System.out.println("Resultado: " + (num1 + num2));
    case 2 -> System.out.println("Resultado: " + (num1 - num2));
    case 3 -> System.out.println("Resultado: " + (num1 * num2));
    case 4 -> {
        if (num2 != 0) System.out.println("Resultado: " + (num1 / num2));
        else System.out.println("Error: División por cero.");
    }
    default -> System.out.println("Opción inválida");
}
```

👉 Implementa una calculadora básica que permite elegir la operación a realizar.  

---

## 🖥️ Ejemplo de uso

```
----- OPERADORES RELACIONALES -----
4 < 5:  true
5 <= 5: true
4 > 5:  false
...

----- USAR EQUALS -----
cadena1 == cadena2: true
cadena1 == cadena3: false
cadena1.equals(cadena3): true

----- CALCULADORA (condicional multiple) -----
Ingrese primer número: 10
Ingrese segundo número: 5
Seleccione operación: 1=Suma, 2=Resta, 3=Multiplicación, 4=División
1
Resultado: 15
```

---

## ✅ Conclusión y aprendizaje

Este proyecto permitió reforzar:  
- El uso de operadores relacionales en comparaciones.  
- La diferencia fundamental entre `==` y `equals` al trabajar con cadenas.  
- El manejo de condicional múltiple con `switch`.  
- La importancia de validar entradas como la división por cero.  
