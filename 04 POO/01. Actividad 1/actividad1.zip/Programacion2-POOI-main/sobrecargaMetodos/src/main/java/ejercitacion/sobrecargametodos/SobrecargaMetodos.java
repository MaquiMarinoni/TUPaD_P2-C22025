/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ejercitacion.sobrecargametodos;

/**
 *
 * @author Usuario
 */
public class SobrecargaMetodos {

    public static void main(String[] args) {
        
        Robot elRobot = new Robot("JavaBot");
        
        elRobot.saludar("Seba");
        elRobot.saludar();
        
       
    }
}
